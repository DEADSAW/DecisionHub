function goBack() {
    // You can implement redirection logic to navigate back to the previous page
    console.log("Back to 1_3_home");
    window.location.href = 'index_1_3_home.html'; // Adjust the redirection URL as needed
}

function debug() {
    // Redirect to 1_3_debug page
    window.location.href = 'index_1_3_debug.html'; // Adjust the redirection URL as needed
}
