function goBack() {
    // Redirect to homepage
    console.log("Navigating back to homepage");
    window.location.href = 'index_1_3_home.html'; // Adjust the redirection URL as needed
    
}

function selectExistingStrategy() {
    // Redirect to 1_3_select page
    console.log("Navigating to 1_3_select page");
    window.location.href = 'index_1_3_select.html'; // Adjust the redirection URL as needed
    
}

function createNewStrategy() {
    // Redirect to 1_3_create page
    console.log("Navigating to 1_3_create page");
    window.location.href = 'index_1_3_create.html'; // Adjust the redirection URL as needed
    
}
