function goBack() {
    // You can implement redirection logic to navigate back to the homepage
    console.log("Back to Home");
}

function goToTesting() {
    // You can implement logic to navigate to the testing page
    console.log("Go to Testing");
}

function saveChanges() {
    // You can implement logic to save the modified rule
    console.log("Changes saved");
}
